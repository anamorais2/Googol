package Meta2Projeto.Gogool;

import java.rmi.*;

/**
* A interface Hello define os metodos que podem ser invocados remotamente.
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public interface Hello extends Remote {

    /**
    * Retorna uma mensagem que contem a URL fornecida.
    * 
    * @param url a URL a ser exibida na mensagem
    * @return uma mensagem que contem a URL fornecida
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    public String sayURL(String url) throws RemoteException;

    /**
    * Retorna uma mensagem que contem a pesquisa fornecida.
    * 
    * @param search a pesquisa a ser exibida na mensagem
    * @return uma mensagem que contem a pesquisa fornecida
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    public String saySearch(String search) throws RemoteException;

    /**
    * Retorna uma mensagem que contem o nome de usuario e senha fornecidos.
    * 
    * @param username o nome de usuario a ser exibido na mensagem
    * @param password a senha a ser exibida na mensagem
    * @return uma mensagem que contem o nome de usuario e senha fornecidos
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    public String sayRegister(String username, String password) throws RemoteException;

    /**
    * Retorna uma mensagem que contem o nome de usuario e senha fornecidos.
    * 
    * @param username o nome de usuario a ser exibido na mensagem
    * @param password a senha a ser exibida na mensagem
    * @return uma mensagem que contem o nome de usuario e senha fornecidos
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    public String sayLogin(String username, String password) throws RemoteException;

    /**
    * Retorna uma mensagem que contem o link fornecido.
    * 
    * @param link o link a ser exibido na mensagem
    * @return uma mensagem que contem o link fornecido
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    public String sayPointToLink(String link) throws RemoteException;

    /**
    * Retorna uma mensagem que contem as estatisticas.
    * 
    * @return uma mensagem que contem as estatisticas
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    public String sayStats() throws RemoteException;

    /**
    * Regista um objeto do tipo BarrelsInter.
    * 
    * @param client o objeto do tipo BarrelsInter a ser registado
    * @return uma mensagem de confirmacao do registo
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    String registerBarrel(BarrelsInter client) throws RemoteException;

    /**
    * Realiza o logout de um objeto do tipo BarrelsInter.
    * 
    * @param client o objeto do tipo BarrelsInter a ser realizado o logout
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    void logoutBarrel (BarrelsInter client) throws RemoteException;
}

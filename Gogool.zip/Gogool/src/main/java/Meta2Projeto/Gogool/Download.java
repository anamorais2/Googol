package Meta2Projeto.Gogool;

import java.rmi.*;

/**
* A interface Download define os metodos para realizar o download de um arquivo.
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public interface Download extends Remote {

    /**
    * Obtem a URL do arquivo a ser baixado.
    * 
    * @param url a URL do arquivo a ser baixado
    * @throws RemoteException se ocorrer um erro de comunicacao remota
    * @throws InterruptedException se a thread for interrompida durante o download
    */

    void GetURL(String url) throws RemoteException, InterruptedException;

    /**
    * Obtem o numero de downloaders ativos.
    * 
    * @return o numero de downloaders ativos
    * @throws RemoteException se ocorrer um erro de comunicacao remota
    */

    public int getNdownloaders() throws RemoteException;
}

package Meta2Projeto.Gogool;

/**
 * Classe que representa uma pesquisa.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
public class Search {

    private String search;

    /**
     * Construtor padrao da classe Search.
     */
    public Search () {}

    /**
     * Construtor da classe Search que recebe uma string de pesquisa.
     * @param search a string de pesquisa
     */
    public Search (String search) {

        this.search = search;
    }

    /**
     * Obtem a string de pesquisa.
     * @return a string de pesquisa
     */
    public String getSearch() {

        return search;
    }

    /**
     * Define a string de pesquisa.
     * @param search a string de pesquisa
     */
    public void setSearch(String search) {

        this.search = search;
    }

}

package Meta2Projeto.Gogool;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

import java.util.List;

/**
 * Representa um registo de usuario do Hacker News.
 * 
 * Um registo de usuario contem informacoes como o ID do usuario, a data de criacao da conta,
 * o karma do usuario, uma descricao sobre o usuario, uma lista de itens submetidos pelo usuario
 * e uma lista de IDs de submissoes do usuario.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public record HackerNewsUserRecord(String id, Long created, Integer karma, String about, List submitted, List<Integer> sub) {

    /**
     * Cria um novo registo de usuario do Hacker News.
     * 
     * @param id O ID do usuario
     * @param created A data de criacao da conta do usuario
     * @param karma O karma do usuario
     * @param about Uma descricao sobre o usuario
     * @param submitted Uma lista de itens submetidos pelo usuario
     * @param sub Uma lista de IDs de submissoes do usuario
     */
    public HackerNewsUserRecord(String id, Long created, Integer karma, String about, List submitted, List<Integer> sub) {
        this.id = id;
        this.created = created;
        this.karma = karma;
        this.about = about;
        this.submitted = submitted;
        this.sub = sub;
    }

    /**
     * Obtem o ID do usuario.
     * 
     * @return O ID do usuario
     */
    public String id() {
        return this.id;
    }

    /**
     * Obtem a data de criacao da conta do usuario.
     * 
     * @return A data de criacao da conta do usuario
     */
    public Long created() {
        return this.created;
    }

    /**
     * Obtem o karma do usuario.
     * 
     * @return O karma do usuario
     */
    public Integer karma() {
        return this.karma;
    }

    /**
     * Obtem uma descricao sobre o usuario.
     * 
     * @return Uma descricao sobre o usuario
     */
    public String about() {
        return this.about;
    }

    /**
     * Obtem uma lista de itens submetidos pelo usuario.
     * 
     * @return Uma lista de itens submetidos pelo usuario
     */
    public List submitted() {
        return this.submitted;
    }

    /**
     * Obtem uma lista de IDs de submissoes do usuario.
     * 
     * @return Uma lista de IDs de submissoes do usuario
     */
    @Override
    public List<Integer> sub() {
        return this.sub;
    }
}



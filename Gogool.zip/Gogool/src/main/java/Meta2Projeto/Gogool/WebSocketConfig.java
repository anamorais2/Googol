package Meta2Projeto.Gogool;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * Classe de configuracao para WebSocket.
 * Configura o broker de mensagens e regista os endpoints do Stomp.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    /**
     * Configura o broker de mensagens.
     * Habilita o broker simples e define o prefixo de destino da aplicacao.
     * @param config O registo de configuracao do broker de mensagens.
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic");
        config.setApplicationDestinationPrefixes("/app");
    }

    /**
     * Regista os endpoints do Stomp.
     * Adiciona o endpoint "/my-websocket" e habilita o uso do SockJS.
     * @param registry O registo de endpoints do Stomp.
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/my-websocket").withSockJS();
    }
}

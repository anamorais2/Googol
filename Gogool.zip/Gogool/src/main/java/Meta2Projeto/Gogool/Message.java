package Meta2Projeto.Gogool;

/**
 * Representa uma mensagem com um conteudo especifico.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
public record Message(String content) {
    /**
     * Constroi uma nova mensagem com o conteudo especificado.
     *
     * @param content o conteudo da mensagem
     */
    public Message(String content) {
        this.content = content;
    }
}

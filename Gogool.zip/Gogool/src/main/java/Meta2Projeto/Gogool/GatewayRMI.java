package Meta2Projeto.Gogool;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * Classe que implementa a interface InterGatewayRMI e representa o gateway RMI.
 * Esta classe define um bean que exporta o servico RMI.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
public class GatewayRMI implements InterGatewayRMI {

    /**
     * Metodo que recebe uma mensagem e retorna uma saudacao com a mensagem e a data atual.
     *
     * @param message a mensagem a ser exibida na saudacao
     * @return a saudacao com a mensagem e a data atual
     */
    @Override
    public String sayHelloRmi(String message) {
        System.out.println("================Server Side ========================");
        System.out.println("Inside Rmi IMPL - Incoming msg : " + message);
        return "Hello " + message + " :: Response time - > " + new Date();
    }

}


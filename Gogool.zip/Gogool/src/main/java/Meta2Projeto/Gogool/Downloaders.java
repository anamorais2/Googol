package Meta2Projeto.Gogool;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.*;
import java.util.Properties;

/**
* A classe Downloaders representa uma thread responsavel por realizar o download de arquivos.
* Ela estende a classe Thread e implementa a logica de download no seu metodo run().
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public class Downloaders extends Thread {

    /**
    * Classe responsavel por realizar o download de arquivos.
    */

    Downloader downloader;

    /**
    * Representa o numero de downloads.
    */
    
    int n;

    /**
    * Constroi um objeto Downloaders com o downloader e o numero especificados.
    * 
    * @param downloader o objeto Downloader responsavel pelo download
    * @param n o numero identificador desta instancia de Downloaders
    */

    public Downloaders(Downloader downloader, int n) {
        this.downloader = downloader;
        this.n = n;
    }

    /**
    * Executa a logica de download de arquivos.
    * Cria um socket multicast e inicia o download usando o objeto Downloader.
    * Imprime mensagens de status durante o processo de download.
    */

    @Override
    public void run() {
        System.out.println("Downloader Starting");
        MulticastSocket socket = null;
        InetAddress group = null;
        try {

            socket = new MulticastSocket(); // cria o socket e o vincula
            String MULTICAST_ADDRESS = "224.3.2.1";
            try (InputStream input = new FileInputStream("config.properties")) {
                Properties prop = new Properties();
                prop.load(input);
                MULTICAST_ADDRESS = prop.getProperty("MULTICAST_ADDRESS");
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
            group = InetAddress.getByName(MULTICAST_ADDRESS);

        } catch (IOException e) {
            e.printStackTrace();
        }

        while (true) {
            if (!downloader.Manager(socket, group)) {
                System.out.println("Estou cansado de trabalhar!" + this.n);
                break;
            }
        }

        System.out.println("Estou saindo: " + this.n);
    }
}


package Meta2Projeto.Gogool;

/**
* A classe Pair representa um par de objetos genericos.
*
* @param <T> o tipo do primeiro objeto
* @param <T1> o tipo do segundo objeto
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public class Pair<T, T1> {
    private T first;
    private T1 second;

    /**
    * Cria um par com os objetos fornecidos.
    *
    * @param first o primeiro objeto do par
    * @param second o segundo objeto do par
    */

    public Pair(T first, T1 second) {
        this.first = first;
        this.second = second;
    }

    /**
    * Retorna o primeiro objeto do par.
    *
    * @return o primeiro objeto do par
    */

    public T getFirst() {
        return first;
    }

    /**
    * Retorna o segundo objeto do par.
    *
    * @return o segundo objeto do par
    */

    public T1 getSecond() {
        return second;
    }

    /**
    * Define o primeiro objeto do par.
    *
    * @param first o novo primeiro objeto do par
    */

    public void setFirst(T first) {
        this.first = first;
    }

    /**
    * Define o segundo objeto do par.
    *
    * @param second o novo segundo objeto do par
    */

    public void setSecond(T1 second) {
        this.second = second;
    }
}

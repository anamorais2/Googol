package Meta2Projeto.Gogool;

/**
 * A classe Login representa as informacoes de login de um usuario.
 * Ela armazena o nome de usuario e a senha associados a uma conta.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
public class Login {

    private String username;
    private String password;

    /**
     * Construtor padrao da classe Login.
     * Cria um objeto Login vazio.
     */
    public Login() {}

    /**
     * Construtor da classe Login.
     * Cria um objeto Login com o nome de usuario e senha especificados.
     *
     * @param username o nome de usuario
     * @param password a senha
     */
    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * Obtem o nome de usuario associado a este objeto Login.
     *
     * @return o nome de usuario
     */
    public String getUsername() {
        return username;
    }

    /**
     * Define o nome de usuario associado a este objeto Login.
     *
     * @param username o nome de usuario
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Obtem a senha associada a este objeto Login.
     *
     * @return a senha
     */
    public String getPassword() {
        return password;
    }

    /**
     * Define a senha associada a este objeto Login.
     *
     * @param password a senha
     */
    public void setPassword(String password) {
        this.password = password;
    }
}

package Meta2Projeto.Gogool;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.*;

/**
* A classe DownloaderServer e responsavel por implementar o servidor de download.
* Ela estende a classe UnicastRemoteObject e implementa a interface Download.
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public class DownloaderServer extends UnicastRemoteObject implements Download {

    /**
    * Classe responsavel por realizar o download de arquivos.
    */

    static Downloader downloader;

    /**
    * Representa uma lista de objetos Downloaders.
    * Esta lista e usada para armazenar os objetos Downloaders que estao a ser utilizados pelo servidor de download.
    */

    static ArrayList<Downloaders> downloaders;
    
    /**
    * Numero de downloaders.
    */
    int ndownloaders;

    /**
    * Construtor da classe DownloaderServer.
    * Inicializa o objeto Downloader e a lista de Downloaders.
    *
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    */

    protected DownloaderServer() throws RemoteException {
        super();
        downloader = new Downloader();
        downloaders = new ArrayList<>();
    }

    /**
    * Metodo para adicionar um URL para download.
    *
    * @param url a URL a ser adicionada para download
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    * @throws InterruptedException se a thread for interrompida durante o processo de download
    */

    @Override
    public void GetURL(String url) throws RemoteException, InterruptedException {
        downloader.addUrl(url);
    }

    /**
    * Metodo para obter o numero de downloaders.
    *
    * @return numero de downloaders
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    */

    @Override
    public int getNdownloaders() throws RemoteException {
        return ndownloaders;
    }

    /**
    * Metodo para definir o numero de downloaders.
    *
    * @param ndownloaders o numero de downloaders a ser definido
    */

    public void setNdownloaders(int ndownloaders) {
        this.ndownloaders = ndownloaders;
    }

    /**
    * Metodo principal que inicia o servidor de download.
    *
    * @param args argumentos da linha de comando
    */

    public static void main(String[] args){
        int num_downloaders = 10;
        try {
            DownloaderServer server = new DownloaderServer();
            int downloadServerPort = 8888;
            try (InputStream input = new FileInputStream("config.properties")) {
                Properties prop = new Properties();
                prop.load(input);
                downloadServerPort = Integer.parseInt(prop.getProperty("DownloadServerPort"));
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
            Registry r = LocateRegistry.createRegistry(downloadServerPort);
            r.rebind("DownloadNameServer", server);
            server.setNdownloaders(num_downloaders);
            System.out.println("Downloader Server pronto!");
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Executando ...");
        for(int id = 0; id <num_downloaders; id++){
            Downloaders downloaders1 = new Downloaders(downloader,id);
            downloaders.add(downloaders1);
        }

        for (Downloaders d: downloaders){
            d.start();
        }

    }

}

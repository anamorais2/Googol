package Meta2Projeto.Gogool;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.*;


/**
* Classe que representa o cliente do sistema Googol.
* O cliente permite interagir com o servidor Googol para realizar operacoes como indexar URLs, realizar buscas, registar usuarios.
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0, fazer login, obter estatisticas e apontar links
*/

public class Client {

    /**
     * Metodo principal que inicia a execucao do programa.
     *
     * @param args argumentos da linha de comando
     */

    public static void main(String[] args) {
            Hello h;
            Scanner input = new Scanner(System.in);
            String gatewayIP = null;
            try (InputStream in = new FileInputStream("config.properties")) {
                Properties prop = new Properties();
                prop.load(in);
                gatewayIP = prop.getProperty("GatewayIP");
                //System.out.println(gatewayIP);

            } catch (IOException ignored) {
            }
            boolean log = false;
            String choice;

                try {

                    h = (Hello) Naming.lookup("rmi://"+ gatewayIP + ":7000/gateway");


                    while (true) {
                        if (!log) {
                            System.out.print("0 - QUIT\n1 - Index URL\n2 - Search\n3 - Register\n4 - Log in\n5 - Get Stats\nOption:");
                        } else {
                            System.out.print("0 - QUIT\n1 - Index URL\n2 - Search\n5 - Get Stats\n6 - Get pointed links\nOption: ");
                        }
                        choice = input.next();
                        input.nextLine();
                        //System.out.println(input);
                        if ("1".equals(choice)) {
                            System.out.println("URL: ");
                            String url = input.next();

                            String message = h.sayURL(url);
                            System.out.println("Server message: " + message);

                        } else if ("2".equals(choice)) {

                            System.out.print("Search: ");
                            String search = input.nextLine();

                            String message = h.saySearch(search);

                            String[] resultados = message.split("\n\n");
                            Scanner scanner = new Scanner(System.in);

                            for (int i = 0; i < resultados.length; i++) {
                                if (i > 0 && i % 10 == 0) {

                                    System.out.println("Press ENTER to see more results...");
                                    scanner.nextLine();
                                }

                                System.out.println(resultados[i]);

                                if (i % 10 == 9 || i == resultados.length - 1) {
                                    System.out.println();
                                }
                            }
                            //System.out.println(message);
                        } else if ("3".equals(choice) && !log) {
                            System.out.print("Username: ");
                            String username = input.next();
                            input.nextLine();
                            System.out.print("password: ");
                            String password = input.next();
                            input.nextLine();

                            String message = h.sayRegister(username, password);
                            System.out.println("Server message: " + message);
                        } else if ("4".equals(choice) && !log) {
                            System.out.print("Username: ");
                            String username = input.next();
                            input.nextLine();
                            System.out.print("password: ");
                            String password = input.next();
                            input.nextLine();

                            String message = h.sayLogin(username, password);
                            System.out.println("Server message: " + message);

                            if (message.equals("Login successfully")) {
                                log = true;
                            }
                        } else if ("6".equals(choice) && log) {

                            System.out.print("URL: ");
                            String link = input.next();
                            input.nextLine();

                            String message = h.sayPointToLink(link);
                            System.out.println(message);

                        } else if ("5".equals(choice)) {

                            String message = h.sayStats();
                            System.out.println(message);
                        } else if ("0".equals(choice)) {
                            break;
                        } else {

                            System.out.println("Not a valid option\n");
                        }
                    }

                } catch (MalformedURLException e) {
                    System.err.println("URL mal formada: " + e.getMessage());
                } catch (NotBoundException e) {
                    System.err.println("Nome nao encontrado no registo: " + e.getMessage());
                } catch (RemoteException e) {
                    System.err.println("Erro remoto: " + e.getMessage());
                } catch (IOException e) {
                    System.err.println("Erro de IO: " + e.getMessage());
                }
    }
}


package Meta2Projeto.Gogool;

import java.io.Serializable;

/**
 * Classe que representa um modelo de URL.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
public class UrlModel implements Serializable {
    /**
     * Representa uma URL.
     */
    private String url;

    /**
     * Representa o titulo de uma URL.
     */
    private String title;

    /**
     * Representa um paragrafo de texto.
     */
    private String paragraph;

    /**
     * Construtor vazio da classe UrlModel.
     */
    public UrlModel() {}

    /**
     * Construtor da classe UrlModel.
     * 
     * @param url       a URL
     * @param title     o titulo
     * @param paragraph o paragrafo
     */
    public UrlModel(String url, String title, String paragraph) {
        this.url = url;
        this.title = title;
        this.paragraph = paragraph;
    }

    /**
     * Obtem o titulo.
     * 
     * @return o titulo
     */
    public String getTitle() {
        return title;
    }

    /**
     * Obtem o paragrafo.
     * 
     * @return o paragrafo
     */
    public String getParagraph() {
        return paragraph;
    }

    /**
     * Obtem a URL.
     * 
     * @return a URL
     */
    public String getUrl() {
        return url;
    }

    /**
     * Define o titulo.
     * 
     * @param title o titulo a ser definido
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Define a URL.
     * 
     * @param url a URL a ser definida
     */
    public void setUrl(String url) {
        this.url = url;
    }
}
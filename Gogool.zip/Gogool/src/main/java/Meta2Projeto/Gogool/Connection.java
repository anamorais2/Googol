package Meta2Projeto.Gogool;

import org.springframework.stereotype.Service;

/**
 * Classe que representa uma conexao com o servidor.
 * Esta classe e responsavel por manter a conexao com o servidor.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
@Service
public class Connection {

    private Hello connection;

    /**
     * Obtem a conexao com o servidor.
     * 
     * @return Conexao com o servidor.
     */
    public Hello getConnection() {
        return connection;
    }

    /**
     * Define a conexao com o servidor.
     * 
     * @param connection A conexao a ser definida com o servidor.
     */
    public void setConnection(Hello connection) {
        this.connection = connection;
    }
}
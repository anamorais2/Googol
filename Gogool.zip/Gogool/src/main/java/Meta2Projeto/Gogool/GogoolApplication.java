package Meta2Projeto.Gogool;


import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Properties;

/**
 * Classe principal que inicia a aplicacao ProjetoMeta2.
 * Esta classe e responsavel por inicializar a aplicacao Spring Boot e configurar a conexao RMI com o servico LoginService.
 * A configuracao da conexao e obtida a partir do arquivo config.properties.
 * 
 *  @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
@SpringBootApplication
@EnableScheduling
public class GogoolApplication {

	@Autowired // Spring procura por um bean correspondente no contexto da aplicacao e o injeta automaticamente na classe onde a anotacao esta presente.
	private Connection loginService;

	/**
	 * Metodo principal que inicia a aplicacao Spring Boot.
	 *
	 * @param args argumentos da linha de comando
	 */
	public static void main(String[] args) {
		SpringApplication.run(GogoolApplication.class, args);
	}
	/**
	 * Metodo executado apos a construcao da classe, utilizado para inicializar a conexao RMI com o servico LoginService.
	 * A configuracao da conexao e obtida a partir do arquivo config.properties.
	 */
	@PostConstruct
	public void init() {
		try (InputStream in = new FileInputStream("config.properties")) {
			Properties prop = new Properties();
			prop.load(in);
			String rmiHost = prop.getProperty("RMI_ADDRESS");
			int rmiPort = Integer.parseInt(prop.getProperty("RMI_PORT"));

			Registry registry = LocateRegistry.getRegistry(rmiHost, rmiPort);
			loginService.setConnection((Hello) registry.lookup("LoginService"));
		} catch (IOException | NotBoundException e) {
			System.out.println("Error initializing RMI connection: " + e.getMessage());
		}
	}
}

package Meta2Projeto.Gogool;

import java.rmi.*;

import sun.misc.Signal;

import java.rmi.server.*;

import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;


/**
* Classe que representa um barrel de armazenamento.
* Implementa a interface BarrelsInter.
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public class StorageBarrel extends UnicastRemoteObject implements BarrelsInter {

    /**
    * Um indice invertido que mapeia uma String para um conjunto de strings.
    * O indice invertido e usado para armazenar informacoes sobre palavras-chave e os seus documentos associados.
    */

    public static ConcurrentHashMap<String, CopyOnWriteArraySet<String>> invertedIndex;

    /**
    * Indice relevante para o barrel de armazenamento.
    */
    
    public static ConcurrentHashMap<String, CopyOnWriteArraySet<String>> relevanteIndex;

    /**
    * Armazena os titulos em um HashMap.
    */

    public static HashMap<String, String> titles;

    /**
    * Representa um barrel de armazenamento que contem paragrafos.
    */

    public static HashMap<String, String> paragraph;

    /**
    * Armazena as pesquisas realizadas, associando cada pesquisa a um valor inteiro.
    */

    public static HashMap<String, Integer> searches;

    /**
    * Regista um novo item no barrel de armazenamento.
    *
     */
    
    static HashMap<String, String> regists;

    /**
    * Armazena o nome do arquivo.
    */

    String filename;

    /**
    * Representa um barrel de armazenamento que contem indices invertidos, indices relevantes, titulos, paragrafos, pesquisas e registos.
    */

    StorageBarrel() throws RemoteException {
        super();
        invertedIndex = new ConcurrentHashMap<>();
        relevanteIndex = new ConcurrentHashMap<>();
        titles = new HashMap<>();
        paragraph = new HashMap<>();
        searches = new HashMap<>();
        regists = new HashMap<>();
    }

    /**
    * Define o nome do arquivo para o barrel de armazenamento.
    * 
    * @param filename o nome do arquivo a ser definido
    */
    
    public void setFilename(String filename) {
        this.filename = filename;
    }

    /**
    * Retorna o nome do arquivo.
    *
    * @return nome do arquivo
    */

    public String getFilename() {
        return filename;
    }

    /**
    * A classe String representa uma sequencia de caracteres.
    * Ela fornece metodos para manipulacao e operacoes comuns em strings.
    * 
    * @see Object
    * @see StringBuilder
    * @see StringBuffer
    * @since 1.0
    */

    @Override
    public String getSearch(String search) throws RemoteException {

        FileWriter writer;

        try {
            writer = new FileWriter(filename, true);
            // Verifica se a palavra-chave ja existe nas pesquisas
            if (searches.get(search) != null) {
                // Se existir, atualiza o contador de ocorrencias
                searches.replace(search, searches.get(search), searches.get(search) + 1);
            } else {
                // Se nao existir, adiciona a lista de pesquisas com contagem 1
                searches.put(search, 1);
            }

            // Regista a pesquisa no ficheiro
            String messageSearch = "Search " + search + " " + searches.get(search);
            writer.write(messageSearch + "\n");
            // System.out.println("1 " + messageSearch + "\n");
            // System.out.println("PALAVRA: " + search + "\n");

            String output = "";
            String[] tokens = search.split(" ");
            System.out.println(Arrays.toString(tokens));

            // Lista de conjuntos de palavras relevantes em relacao as pesquisas
            ArrayList<CopyOnWriteArraySet<String>> relevantIndexArray = new ArrayList<>();

            // Preenche a lista de conjuntos relevantes com base nas palavras-chave da pesquisa
            for (String string : tokens) {
                CopyOnWriteArraySet<String> set = invertedIndex.get(string);
                relevantIndexArray.add(set);
            }

            System.out.println(relevantIndexArray + "\n");

            // Realiza a intersecao dos conjuntos relevantes para obter URLs relevantes
            for (int i = 1; i < relevantIndexArray.size(); i++) {
                if (relevantIndexArray.get(i) == null) {
                    // Se uma palavra-chave nao for encontrada, encerra a busca
                    try {
                        writer.close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    return "No results found";
                }
                relevantIndexArray.get(0).retainAll(relevantIndexArray.get(i));
            }

            System.out.println(relevantIndexArray + "\n");

            // Lista de URLs relevantes
            ArrayList<String> relevantUrl = new ArrayList<>();
            if (relevantIndexArray.get(0) != null) {
                relevantUrl = new ArrayList<>(relevantIndexArray.get(0));

                System.out.println(relevantUrl);
                // Ordena as URLs relevantes com base no tamanho dos conjuntos relevantes
                relevantUrl.sort((s, t1) -> {
                    // Obtem o tamanho dos conjuntos de cada URL, assumindo 0 se nao houver conjunto
                    int sizeS = relevanteIndex.containsKey(s) ? relevanteIndex.get(s).size() : 0;
                    int sizeT1 = relevanteIndex.containsKey(t1) ? relevanteIndex.get(t1).size() : 0;

                    // Compara os tamanhos de forma decrescente
                    return Integer.compare(sizeT1, sizeS);
                });
            }

            // Coloca no output as informacoes relevantes sobre as URLs encontradas
            if (relevantUrl.size() > 0) {
                for (String urlFromRelevant : relevantUrl) {

                    String title = titles.get(urlFromRelevant);
                    if (title == null) {
                        title = "No title";
                    }
                    String p = paragraph.get(urlFromRelevant);
                    if (p == null) {
                        p = " ";
                    }
                    output = output.concat(" " + title + " " + urlFromRelevant + " " + p + "\n\n");
                }
            } else {
                output = "No results found";
            }

            writer.close();
            return output;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    /**
    * Retorna uma string que contem os pontos que apontam para o ponto especificado.
    *
    * @param point o ponto para o qual se deseja obter os pontos que apontam para ele
    * @return uma string que contem os pontos que apontam para o ponto especificado
    * @throws RemoteException se ocorrer um erro durante a execucao remota
    */

    @Override
    public String getPointToLink(String point) throws RemoteException {
        CopyOnWriteArraySet<String> aux = relevanteIndex.get(point);
        String output = "";
        if (aux != null) {
            for (String s : aux) {
                output = output.concat(s + "\n");
            }
        }

        return output;
    }

    /**
    * Retorna as estatisticas das pesquisas realizadas.
    *
    * @return uma string que contem as estatisticas das pesquisas realizadas
    * @throws RemoteException se ocorrer um erro durante a execucao remota
    */

    public String getStats() throws RemoteException {

        String output = "Most searched:\n";

        if (searches.isEmpty()) {
            return "No searches done\n";
        }

        // Cria uma lista de entradas do mapa, onde cada entrada e um par chave-valor, e entao a ordena com base nos valores, em ordem decrescente.
        List<Map.Entry<String, Integer>> list = new ArrayList<>(searches.entrySet()); //Isso basicamente converte o conjunto de entradas do mapa numa lista.
        list.sort((obj1, obj2) -> obj2.getValue().compareTo(obj1.getValue()));

        //Collections.sort(list, (entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));

        Map<String, Integer> sortedMap = new LinkedHashMap<>(); //  preservar a ordem de insercao das entradas ordenadas
        for (Map.Entry<String, Integer> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        // Itera sobre as entradas ordenadas e extrai as dez primeiras, concatenando os seus valores formatados numa string de saida.
        int con = 1;
        for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {

            output = output.concat(con + " - '" + entry.getKey() + "'\n");

            con++;

            if (con > 10) break;

        }


        return output;
    }

    /**
    * Regista um usuario com o nome de usuario e senha fornecidos.
    * 
    * @param username O nome de usuario a ser registado
    * @param password A senha do usuario a ser registada
    * @return Uma mensagem indicando se o registo foi realizado com sucesso ou se o nome de usuario ja esta em uso
    * @throws RemoteException Se ocorrer um erro durante a execucao do metodo remoto
    */

    @Override
    public String regist(String username, String password) throws RemoteException {

        FileWriter writer;
        String output;

        try {
            writer = new FileWriter(filename, true);

            if (regists.get(username) == null) {
                regists.put(username, password);
                String messageRegister = "Regist " + username + " " + password;
                writer.write(messageRegister + "\n");
                output = "Successfully registered";
            } else {
                output = "Username already registed";
            }

            writer.close();
            return output;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
    * Verifica o login do usuario com base no nome de usuario e senha fornecidos.
    * 
    * @param username O nome de usuario fornecido
    * @param password A senha fornecida
    * @return Uma mensagem indicando o resultado do login
    * @throws RemoteException Se ocorrer um erro durante a execucao remota
    */

    @Override
    public String login(String username, String password) throws RemoteException {
        String output;

        if (regists.get(username) == null) {
            output = "Not registered";
        } else {
            if (Objects.equals(regists.get(username), password)) {
                output = "Login successfully";
            } else {
                output = "Wrong password";
            }
        }
        return output;
    }

    /**
    * Metodo principal do programa.
    * 
    * @param args argumentos da linha de comando
    */

    public static void main(String[] args) {

        // recebe o caminho do ficheiro
        if (args.length != 1) {
            System.out.println("Wrong number of arguments.");
            System.exit(0);
        }

        FileWriter writer;
        try {
            writer = new FileWriter(args[0], true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            String gatewayIP = "127.0.0.1";
            int barrelPort = 5000;
            try (InputStream in = new FileInputStream("config.properties")) {
                Properties prop = new Properties();
                prop.load(in);
                gatewayIP = prop.getProperty("GatewayIP");
                barrelPort = Integer.parseInt(prop.getProperty("BarrelPort"));
                System.out.println(gatewayIP);

            } catch (IOException ignored) {
            }
            try {
                Hello server = (Hello) Naming.lookup("rmi://"+ gatewayIP + ":" + barrelPort + "/barrel");
                //Hello server = (Hello) LocateRegistry.getRegistry(5000).lookup("barrel");
                StorageBarrel sB = new StorageBarrel();
                sB.setFilename(args[0]);
                String message = server.registerBarrel(sB);
                System.out.println(message);
                Signal.handle(new Signal("INT"), sig -> {
                    try {
                        server.logoutBarrel(sB);
                        writer.close();

                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    System.exit(0);
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        try {
            File file = new File(args[0]);
            if (file.exists()) {
                String title, url, type, token, mUrl, search, username, password;
                int nSearch;
                Scanner scanner = new Scanner(file);
                while (scanner.hasNextLine()) {
                    String info = scanner.nextLine();
                    System.out.println(info + " c");
                    String[] tokens = info.split(" ");

                    if (tokens.length >= 3) {

                        switch (tokens[0]) {
                            case "Title":
                                url = tokens[1];
                                title = tokens[2];
                                for (int i = 3; i < tokens.length; ++i)
                                    title = title.concat(" " + tokens[i]);

                                titles.put(url, title);
                                break;

                            case "Paragraph":
                                url = tokens[1];
                                type = tokens[2];
                                for (int i = 3; i < tokens.length; ++i)
                                    type = type.concat(" " + tokens[i]);

                                paragraph.put(url, type);

                                break;
                            case "Token":
                                try {
                                    url = tokens[1];
                                    token = tokens[2];
                                    CopyOnWriteArraySet<String> index = invertedIndex.get(token);
                                    if (index == null) {
                                        index = new CopyOnWriteArraySet<>();
                                        index.add(url);
                                        invertedIndex.put(token, index);
                                    } else {
                                        index.add(url);
                                    }
                                } catch (Exception e) {
                                    throw new RuntimeException(e);
                                }
                                break;

                            case "Url":
                                url = tokens[1];
                                mUrl = tokens[2];
                                CopyOnWriteArraySet<String> value = relevanteIndex.get(mUrl);
                                if (value == null) {
                                    CopyOnWriteArraySet<String> set = new CopyOnWriteArraySet<>();
                                    set.add(url);
                                    relevanteIndex.put(mUrl, set);
                                } else {
                                    value.add(url);
                                    relevanteIndex.put(mUrl, value);
                                }

                                break;

                            case "Search":
                                search = tokens[1];
                                nSearch = Integer.parseInt(tokens[tokens.length - 1]);

                                for (int i = 2; i < tokens.length - 1; ++i)
                                    search = search.concat(" " + tokens[i]);
                                System.out.println(search + "\n");
                                if (searches.get(search) != null) {
                                    searches.replace(search, searches.get(search), nSearch);
                                } else {
                                    searches.put(search, nSearch);
                                }
                                break;

                            case "Regist":
                                username = tokens[1];
                                password = tokens[2];

                                regists.putIfAbsent(username, password);
                                break;
                        }
                    }
                }
                scanner.close();
            } else {
                if (!file.createNewFile())
                    System.exit(0);
                else System.out.println("File created");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        MulticastSocket socket = null;

        try {
            int multicastPort = 4321;
            String multicastAdress = "224.3.2.1";
            try (InputStream input = new FileInputStream("config.properties")) {
                Properties prop = new Properties();
                prop.load(input);
                multicastPort = Integer.parseInt(prop.getProperty("MULTICAST_PORT"));
                multicastAdress = prop.getProperty("MULTICAST_ADDRESS");
            } catch (IOException ignored) {
            }
            socket = new MulticastSocket(multicastPort);
            InetAddress group = InetAddress.getByName(multicastAdress);
            socket.joinGroup(group);

            String title, url, type, token, mUrl;
            byte[] buffer = new byte[256];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

            while (true) {

                socket.receive(packet);

                type = new String(packet.getData(), 0, packet.getLength());
                String[] tokens = type.split(" ");

                //System.out.println(tokens[0] + tokens[1] + tokens[2]);

                if (tokens.length >= 3 && !tokens[0].isEmpty() && !tokens[1].isEmpty() && !tokens[2].isEmpty()){
                    writer.write(type + "\n");
                    System.out.println(type);
                    switch (tokens[0]) {
                        case "Title":
                            url = tokens[1];
                            title = tokens[2];
                            for (int i = 3; i < tokens.length; ++i)
                                title = title.concat(" " + tokens[i]);

                            titles.put(url, title);
                            System.out.println(titles + "\n");

                            break;

                        case "Paragraph":
                            url = tokens[1];
                            type = tokens[2];
                            for (int i = 3; i < tokens.length; ++i)
                                type = type.concat(" " + tokens[i]);

                            paragraph.put(url, type);

                            break;

                        case "Token":
                            try {
                                url = tokens[1];
                                token = tokens[2];
                                CopyOnWriteArraySet<String> index = invertedIndex.get(token);
                                if (index == null) {
                                    index = new CopyOnWriteArraySet<>();
                                    index.add(url);
                                    invertedIndex.put(token, index);
                                } else {
                                    index.add(url);
                                }
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                            break;

                        case "Url":

                            url = tokens[1];
                            mUrl = tokens[2];
                            CopyOnWriteArraySet<String> value = relevanteIndex.get(mUrl);
                            if (value == null) {
                                CopyOnWriteArraySet<String> set = new CopyOnWriteArraySet<>();
                                set.add(url);
                                relevanteIndex.put(mUrl, set);
                            } else {
                                value.add(url);
                                relevanteIndex.put(mUrl, value);
                            }

                            break;
                    }

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            assert socket != null;
            socket.close();
        }
    }

}



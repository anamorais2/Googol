package Meta2Projeto.Gogool;

/**
 * Esta interface define os metodos para comunicacao entre gateways usando RMI.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
public interface InterGatewayRMI {

    /**
     * Retorna uma mensagem de saudacao.
     *
     * @param message a mensagem a ser exibida
     * @return a mensagem de saudacao
     */
    String sayHelloRmi(String message);
}

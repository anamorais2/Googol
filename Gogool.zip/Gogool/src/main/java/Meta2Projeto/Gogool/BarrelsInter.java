package Meta2Projeto.Gogool;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
* A interface BarrelsInter define os metodos que podem ser invocados remotamente.
* Esta interface estende a interface Remote para permitir a comunicacao remota entre objetos.
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public interface BarrelsInter extends Remote {

    /**
    * Retorna uma string que contem o resultado da pesquisa baseada no parametro de busca fornecido.
    *
    * @param search a string de busca
    * @return uma string que contem o resultado da pesquisa
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    */

    String getSearch(String search) throws RemoteException;

    /**
    * Retorna uma string que contem o link correspondente ao ponto fornecido.
    *
    * @param point o ponto para o qual obtem o link
    * @return uma string que contem o link correspondente ao ponto
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    */

    String getPointToLink(String point) throws RemoteException;

    /**
    * Retorna uma string que contem as estatisticas.
    *
    * @return uma string que contem as estatisticas
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    */

    public String getStats() throws RemoteException;

    /**
    * Regista um usuario com o nome de usuario e senha fornecidos.
    *
    * @param username o nome de usuario do usuario a ser registado
    * @param password a senha do usuario a ser registado
    * @return uma string indicando o resultado do registo
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    */

    public String regist(String username, String password) throws RemoteException;

    /**
    * Realiza o login de um usuario com o nome de usuario e senha fornecidos.
    *
    * @param username o nome de usuario do usuario a ser logado
    * @param password a senha do usuario a ser logado
    * @return uma string indicando o resultado do login
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    */

    public String login(String username, String password) throws RemoteException;
}


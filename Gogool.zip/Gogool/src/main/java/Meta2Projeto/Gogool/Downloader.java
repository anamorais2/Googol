package Meta2Projeto.Gogool;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.URL;
import java.util.*;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * A classe Downloader e responsavel por gerir o download de URLs.
 * Ela possui uma fila de links sincronizados e um conjunto de links para evitar o processamento duplicado de URLs.
 * Alem disso, possui um limite maximo de links que podem ser baixados.
 *
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */

public class Downloader {

    /**
     * Fila de URLs a serem baixadas.
     */

    public SynQueue<String> urlQueue; // Fila de links sincronizados

    /**
     * Conjunto de URLs ja baixadas.
     */

    public CopyOnWriteArraySet<Object> urlSet; // Conjunto de links evita o processamento duplicado de Url's

    /**
     * Representa o numero maximo de links que podem ser baixados.
     */

    private int maxLinks;

    /**
     * Construtor da classe Downloader.
     * Inicializa a fila de URLs e o conjunto de URLs.
     */

    public Downloader() {
        super();
        this.urlQueue = new SynQueue<>();
        this.urlSet = new CopyOnWriteArraySet<>();

    }

    /**
     * Verifica se uma determinada URL e valida.
     *
     * @param urlString a string da URL a ser verificada
     * @return true se a string da URL for valida, false caso contrario
     */

    private boolean isValidURL(String urlString) {
        try {
            new URL(urlString).toURI();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Retorna a fila de URLs usada pelo downloader.
     *
     * @return a fila de URLs usada pelo downloader
     */

    public SynQueue<String> getUrlQueue() {
        return urlQueue;
    }

    /**
     * Retorna o conjunto de URLs.
     *
     * @return o conjunto de URLs
     */

    public CopyOnWriteArraySet<Object> getUrlSet() {
        return urlSet;
    }

    /**
     * Retorna o numero maximo de links permitidos.
     *
     * @return O numero maximo de links permitidos
     */

    synchronized public int getMaxLinks() {
        return maxLinks;
    }

    /**
     * Retorna o tamanho do conjunto de URLs.
     *
     * @return O tamanho do conjunto de URLs
     */

    synchronized public int getSizeUrlSet() {
        return this.urlSet.size();
    }

    /**
     * Define a fila de URLs para o downloader.
     *
     * @param urlQueue a fila de URLs a ser definida
     */

    public void setUrlQueue(SynQueue<String> urlQueue) {
        this.urlQueue = urlQueue;
    }

    /**
     * Define o conjunto de URLs a serem baixadas.
     *
     * @param urlSet O conjunto de URLs a serem baixadas
     */

    public void setUrlSet(CopyOnWriteArraySet<Object> urlSet) {
        this.urlSet = urlSet;
    }

    /**
     * Define o numero maximo de links que podem ser processados pelo downloader.
     *
     * @param maxLinks O numero maximo de links a serem processados
     */

    synchronized public void setMaxLinks(int maxLinks) {
        this.maxLinks = maxLinks;
    }

    /**
     * Adiciona um URL a lista de URLs do downloader.
     *
     * @param url a URL a ser adicionada
     * @throws InterruptedException se a thread for interrompida durante a execucao
     */

    public void addUrl (String url) throws InterruptedException {

        if (this.maxLinks >= this.urlSet.size()) {
            int value = getMaxLinks();
            setMaxLinks(value + 1024);
            this.urlSet.add(url);
            this.urlQueue.add(url);
        } else {
            setMaxLinks(this.urlSet.size());
        }
    }

    /**
     * Gerencia o processo de download de URLs.
     *
     * @param socket O socket multicast para envio dos pacotes
     * @param group O endereco de grupo multicast
     * @return true se o processo de gestao foi concluido com sucesso, caso contrario, false
     */

    boolean Manager(MulticastSocket socket, InetAddress group) {
        String url, aux = null, message;

        try {
            url = urlQueue.pop();
            //System.out.println(url);
            if (url == null || !isValidURL(url)) {
                System.out.println("URL invalida ou nula: " + url);
                return true; // Continua o loop, considerando o erro como nao critico
            }

            Document doc = Jsoup.connect(url).get();
            StringTokenizer tokens = new StringTokenizer(doc.text());


            String title = doc.title();
            if (title.equals("")) {
                title = "No exist title";
            }

            message = "Title" + " " + url + " " + title;

            byte[] buffer = message.getBytes();
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, group, 4321);
            socket.send(packet);

            String text;
            Element Paragraph = doc.select("p").first(); // Retornara o primeiro paragrafo
            if (Paragraph != null) {
                text = Paragraph.text();
                if (text.equals("")) {
                    text = " No exist paragraph";
                }
            } else {
                text = " No exist paragraph";
            }

            message = "Paragraph" + " " + url + " " + text;

            buffer = message.getBytes();
            packet = new DatagramPacket(buffer, buffer.length, group, 4321);
            socket.send(packet);

            int countTokens = 0;
            String token = null;
            while (tokens.hasMoreElements() && countTokens++ < 100) {
                token = tokens.nextToken().toLowerCase();
                if (token.equals("")) {
                    token = "No exist token";
                }
                message = "Token" + " " + url + " " + token;
                buffer = message.getBytes();
                packet = new DatagramPacket(buffer, buffer.length, group, 4321);
                socket.send(packet);
            }

            //System.out.println("Size:" + urlSet.size() + " Capacity: "+  getMaxLinks());
            //System.out.println("Size: " + urlQueue.size());

            if (getSizeUrlSet() < getMaxLinks()) {
                Elements links = doc.select("a[href]");
                for (Element link : links) {
                    //System.out.println(link.text() + "\n" + link.attr("abs:href") + "\n");
                    aux = link.attr("abs:href");
                    System.out.println(aux);
                    System.out.println(aux.length());
                    message = "Url" + " " + url + " " + aux;

                    buffer = message.getBytes();
                    packet = new DatagramPacket(buffer, buffer.length, group, 4321);
                    socket.send(packet);

                    if (!urlSet.contains(aux) && (getSizeUrlSet() < getMaxLinks())) {
                        urlQueue.add(aux);
                        urlSet.add(aux);
                    }
                }

            }

        } catch (IOException ex) {
            System.out.println("IOException Manager");
        } catch (InterruptedException ex) {
            System.out.println("InterruptedException Manager");
        }catch (IllegalArgumentException ie) {
            System.out.println("IllegalArgumentException Manager");
        }

        return true;
    }

}



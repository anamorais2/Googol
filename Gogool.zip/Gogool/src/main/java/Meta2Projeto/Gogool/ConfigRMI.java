package Meta2Projeto.Gogool;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiServiceExporter;
import org.springframework.remoting.support.RemoteExporter;

/**
 * Classe de configuracao para a exportacao de servicos RMI.
 * Esta classe define um bean que exporta o servico RMI.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
@Configuration
public class ConfigRMI {

    @Bean
    RemoteExporter registerRMIExporter() {
        RmiServiceExporter exporter = new RmiServiceExporter();
        exporter.setServiceName("helloworldrmi");
        exporter.setServiceInterface(InterGatewayRMI.class);
        exporter.setService(new GatewayRMI());
        return exporter;
    }
}

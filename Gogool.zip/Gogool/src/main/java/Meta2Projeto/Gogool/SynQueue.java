package Meta2Projeto.Gogool;

import java.util.*;

/**
* A classe SynQueue representa uma fila sincronizada que suporta operacoes de adicao e remocao de elementos.
* Ela e implementada usando uma estrutura de dados de fila (Queue) e possui uma capacidade maxima.
*
* @param <E> o tipo de elementos armazenados na fila
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public class SynQueue<E> {

    /**
    * Fila que armazena os elementos da classe E.
    */

    private final Queue<E> queue;

    /**
    * Capacidade maxima da fila.
    */
    
    private final int capacity;

    /**
    * Cria uma instancia de SynQueue com capacidade maxima igual a Integer.MAX_VALUE.
    */

    public SynQueue() {
        this.queue = new LinkedList<>();
        this.capacity = Integer.MAX_VALUE;
    }
 
    /**
    * Cria uma instancia de SynQueue com a capacidade maxima especificada.
    *
    * @param capacity a capacidade maxima da fila
    */

    public SynQueue(int capacity){
        this.queue = new LinkedList<>();
        this.capacity = capacity;
    }
 
    /**
    * Adiciona um elemento a fila, se a capacidade maxima nao tiver sido atingida.
    * Se a fila estiver vazia, notifica todas as threads em espera.
    *
    * @param element o elemento a ser adicionado a fila
    * @throws InterruptedException se a thread for interrompida enquanto estiver esperando
    */

    public synchronized void add(E element) throws InterruptedException {
        if (this.queue.size() == this.capacity)
            return;
        if (this.queue.size() == 0) {
            notifyAll();
        }
        this.queue.add(element);
    }
    
    /**
    * Remove e retorna o elemento na frente da fila.
    * Se a fila estiver vazia, a thread sera colocada em espera ate que um elemento seja adicionado.
    *
    * @return o elemento removido da fila
    * @throws InterruptedException se a thread for interrompida enquanto estiver esperando
    */

    public synchronized E pop() throws InterruptedException {
        while (this.queue.size() == 0) {
            wait();
        }
        return this.queue.remove();
    }

    /**
    * Retorna o numero de elementos na fila.
    *
    * @return o numero de elementos na fila
    */

    public synchronized int size () {
        return this.queue.size();
    }
}
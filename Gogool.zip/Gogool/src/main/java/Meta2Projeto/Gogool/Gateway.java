package Meta2Projeto.Gogool;

import org.springframework.context.annotation.Bean;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.util.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.remoting.rmi.RmiProxyFactoryBean;

/**
* A classe Gateway e responsavel por atuar como um gateway entre os clientes e os objetos remotos do tipo BarrelsInter.
* Ela implementa a interface Hello, que define os metodos remotos que podem ser invocados pelos clientes.
* Alem disso, ela estende a classe UnicastRemoteObject para fornecer suporte a comunicacao remota.
* Esta classe mantem uma lista de objetos BarrelsInter registados e gerencia a execucao de operacoes nesses objetos.
* Tambem regista e calcula o tempo de resposta das operacoes executadas nos objetos BarrelsInter.
* Os metodos remotos implementados nesta classe permitem que os clientes realizem operacoes como adicionar um URL, realizar uma pesquisa, registar-se, fazer login, obter um link e obter estatisticas sobre os objetos BarrelsInter.
* Alem disso, a classe Gateway tambem possui um objeto Download que e usado para realizar o download de arquivos.
* Para iniciar o gateway, e necessario chamar o metodo main desta classe.
*
* @author Ana Carolina Morais e Fernanda Fernandes
* @version 1.0
*/

public class Gateway extends UnicastRemoteObject implements Hello {

    /**
    * Representa uma conexao de download.
    */

    public static Download conection;
    
    /**
    * Armazena um mapeamento de chaves e valores para indexacao.
    */

    static HashMap<String, String> index;

    /**
    * Representa uma lista de clientes com os seus respetivos barrels e o estado de conexao.
    */

    static ArrayList<Pair<BarrelsInter, Boolean>> clients;

    /**
    * Mapeia o tempo de resposta por barrel.
    * 
    * <p> Esta estrutura de dados armazena os tempos de resposta para cada barrel.
    * Cada barrel e mapeado para uma lista de tempos de resposta representados como valores longos.
    */

    static ConcurrentHashMap<BarrelsInter, List<Long>> responseTimesByBarrel = new ConcurrentHashMap<>();

    /**
     * A porta RMI utilizada pelo gateway.
    */
    private int rmiPort = 6000;

    /**
     * Classe responsavel por criar um proxy RMI para acessar um servico remoto.
    */
    @Bean
    RmiProxyFactoryBean rmiProxy() {

        String rmiAddress = "127.0.0.1";
        try (InputStream input = new FileInputStream("config.properties")) {
            Properties prop = new Properties();
            prop.load(input);
            rmiPort = Integer.parseInt(prop.getProperty("RMI_PORT"));
            rmiAddress = prop.getProperty("RMI_ADDRESS");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        RmiProxyFactoryBean bean = new RmiProxyFactoryBean();
        bean.setServiceInterface(Hello.class);
        bean.setServiceUrl("rmi://" + rmiAddress + ":" + rmiPort + "/helloworldrmi");

        return bean;
    }

    /**
    * Constroi um novo objeto Gateway.
    * Esta classe representa um gateway para comunicacao entre clientes e o servidor.
    * Inicializa as estruturas de dados de indice e clientes.
    *
    * @throws RemoteException se houver um problema com a invocacao de metodo remoto
    */

    public Gateway() throws RemoteException {
        super();
        index = new HashMap<>();
        clients = new ArrayList<>();
    }

    /**
    * Executa uma operacao num objeto de barrels e regista o tempo de resposta.
    * 
    * @param barrel o objeto de barrels em que a operacao sera executada
    * @param operation a operacao a ser executada
    */

    public void executeBarrelOperation(BarrelsInter barrel, Runnable operation) {
        long startTime = System.nanoTime();

        operation.run(); // Supoe-se que essa chamada bloqueia ate a operacao terminar

        long endTime = System.nanoTime();
        long responseTime = (endTime - startTime) / 1_000_000; // Convertendo de nanossegundos para milissegundos

        responseTimesByBarrel.computeIfAbsent(barrel, k -> new ArrayList<>()).add(responseTime);
    }

    /**
    * Retorna uma mensagem indicando que a URL foi adicionada.
    * 
    * @param url a URL a ser processada
    * @return uma mensagem indicando que a URL foi adicionada
    * @throws RemoteException se ocorrer um erro de comunicacao remota
    */

    @Override
    public String sayURL(String url) throws RemoteException {
        System.out.println("server: " + url);
        try {

            conection.GetURL(url);

        } catch (Exception e) {
            System.out.println("Exception: in 8888 " + e);
            e.printStackTrace();
        }

        return "URL ADD";
    }

    /**
    * Retorna o resultado da pesquisa em uma string.
    *
    * @param search a string que contem o termo de pesquisa
    * @return uma string que contem o resultado da pesquisa
    * @throws RemoteException se ocorrer um erro durante a execucao remota
    */

    @Override
    public String saySearch(String search) throws RemoteException {
        String output = "No StorageBarrel available";
        long startTime, endTime;

        for (Pair<BarrelsInter, Boolean> pair : clients) {
            if (!pair.getSecond()) {
                pair.setSecond(true);

                startTime = System.currentTimeMillis(); // Regista o tempo de inicio

                output = pair.getFirst().getSearch(search); // Executa a pesquisa

                endTime = System.currentTimeMillis(); // Regista o tempo de fim

                // Calcula o tempo de resposta e armazena
                long responseTime = endTime - startTime;
                responseTimesByBarrel.computeIfAbsent(pair.getFirst(), k -> new ArrayList<>()).add(responseTime);

                pair.setSecond(false);
            }
        }

        return output;
    }

    /**
    * Regista um usuario no sistema.
    *
    * @param username O nome de usuario a ser registado
    * @param password A senha do usuario a ser registada
    * @return Uma mensagem indicando o resultado do registo
    * @throws RemoteException Se ocorrer um erro durante a comunicacao remota
    */

    @Override
    public String sayRegister(String username, String password) throws RemoteException {
        String output = "No StorageBarrel available";
        for (Pair<BarrelsInter, Boolean> pair : clients) {
            if (!pair.getSecond()) {
                pair.setSecond(true);
                output = pair.getFirst().regist(username, password);
                pair.setSecond(false);
            }
        }

        return output;
    }

    /**
    * Retorna uma mensagem de login com base no nome de usuario e senha fornecidos.
    * 
    * @param username O nome de usuario fornecido
    * @param password A senha fornecida
    * @return Uma mensagem de login
    * @throws RemoteException Se ocorrer um erro durante a execucao remota
    */

    @Override
    public String sayLogin(String username, String password) throws RemoteException {
        String output = "No StorageBarrel available";
        for (Pair<BarrelsInter, Boolean> pair : clients) {
            if (!pair.getSecond()) {
                pair.setSecond(true);
                output = pair.getFirst().login(username, password);
                pair.setSecond(false);
                break;
            }
        }

        return output;
    }

    /**
    * Retorna uma string que representa o ponto de acesso ao link especificado.
    * 
    * @param link o link para o qual o ponto de acesso sera retornado
    * @return uma string que representa o ponto de acesso ao link especificado
    * @throws RemoteException se ocorrer um erro durante a chamada remota
    */

    @Override
    public String sayPointToLink(String link) throws RemoteException {
        String output = "No StorageBarrel available";
        for (Pair<BarrelsInter, Boolean> pair : clients) {
            if (!pair.getSecond()) {
                pair.setSecond(true);
                output = pair.getFirst().getPointToLink(link);
                pair.setSecond(false);
                break;
            }
        }

        return output;
    }

    /**
    * Retorna uma string que contem as estatisticas do Gateway.
    * As estatisticas incluem as estatisticas de cada Barrel, o tempo medio de resposta para cada Barrel,
    * o numero de Barrels ativos e o numero de Downloaders ativos.
    *
    * @return uma string que contem as estatisticas do Gateway
    * @throws RemoteException se houver um erro de comunicacao remota
    */
    
    @Override
    public String sayStats() throws RemoteException {
        StringBuilder output = new StringBuilder();

        if (!clients.isEmpty()) {
            for (Pair<BarrelsInter, Boolean> pair : clients) {
                if (!pair.getSecond()) {
                    pair.setSecond(true);

                    // Chamada para o metodo getStats() de cada Barrel
                    String barrelStats = pair.getFirst().getStats();
                    output.append(barrelStats).append("\n");

                    // Identificador ou nome do Barrel para exibicao
                    String barrelId = pair.getFirst().toString(); // Ajuste conforme necessario

                    // Calculando o tempo medio de resposta
                    List<Long> responseTimes = responseTimesByBarrel.getOrDefault(pair.getFirst(), new ArrayList<>());
                    if (!responseTimes.isEmpty()) {
                        double averageResponseTime = responseTimes.stream().mapToLong(Long::longValue).average().getAsDouble();
                        output.append("Average Response Time for ").append(barrelId).append(": ")
                                .append(String.format("%.2f ms", averageResponseTime)).append("\n");
                    } else {
                        output.append("No response time data available for Barrel ").append(barrelId).append("\n");
                    }

                    pair.setSecond(false);
                }
            }
        } else {
            output.append("No StorageBarrel available\n");
        }

        output.append("Number of Active Barrels: ").append(clients.size()).append("\n");
        output.append("Number of Active Downloaders: ").append(conection != null ? conection.getNdownloaders() : "N/A").append("\n");

        return output.toString();
    }

    /**
    * Regista um barrel no sistema.
    * 
    * @param client o cliente do  a barrel ser registado
    * @return uma mensagem indicando que o barrel foi registado com sucesso
    * @throws RemoteException se ocorrer um erro durante a comunicacao remota
    */

    @Override
    public String registerBarrel(BarrelsInter client) throws RemoteException {
        clients.add(new Pair<>(client, false));
        System.out.println("Barrel Resgisted!");
        return "Barrel Registed";
    }

    /**
    * Regista a saida de um cliente do barrel.
    *
    * @param client o cliente a ser registado
    * @throws RemoteException se houver um problema relacionado a comunicacao
    */
   
    @Override
    public void logoutBarrel(BarrelsInter client) throws RemoteException {
        boolean remove = clients.removeIf(obj -> obj.getFirst().equals(client));
        if (remove) {
            System.out.println("\nBarrel Removed!\n");
        }
    }

    /**
    * Metodo principal que inicia a execucao do programa.
    *
    * @param args argumentos da linha de comando
    */

    public static void main(String[] args) {
        try {

            System.getProperties().put("java.security.policy", "policy.all");
            Hello h = new Gateway();
            int GatewayPort = 7000;
            try (InputStream input = new FileInputStream("config.properties")) {
                Properties prop = new Properties();
                prop.load(input);
                GatewayPort = Integer.parseInt(prop.getProperty("GatewayPort"));
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
            //System.out.println(GatewayPort);
            LocateRegistry.createRegistry(GatewayPort).rebind("gateway", h);

        } catch (RemoteException e) {
            System.out.println("Exception in main: " + e);
        }

        try {
            int downloadServerPort = 8888;
            try (InputStream input = new FileInputStream("config.properties")) {
                Properties prop = new Properties();
                prop.load(input);
                downloadServerPort = Integer.parseInt(prop.getProperty("DownloadServerPort"));
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
            conection = (Download) LocateRegistry.getRegistry(downloadServerPort).lookup("DownloadNameServer");
        } catch (Exception e) {

            System.out.println("Exception in 8888: " + e);
            e.printStackTrace();
        }

        try {
            Gateway gateway = new Gateway();
            int barrelPort = 5000;
            try (InputStream input = new FileInputStream("config.properties")) {
                Properties prop = new Properties();
                prop.load(input);
                barrelPort = Integer.parseInt(prop.getProperty("BarrelPort"));
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            LocateRegistry.createRegistry(barrelPort).rebind("barrel", gateway);
            System.out.println("Gateway ready.");

        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }

        try {
            Gateway loginService = new Gateway();
            LocateRegistry.createRegistry(6000).rebind("LoginService",loginService);
            System.out.println("RMI server ready to receive connections...");
        } catch (Exception e) {
            System.err.println("RMI server error: " + e);
            e.printStackTrace();
        }


    }
}


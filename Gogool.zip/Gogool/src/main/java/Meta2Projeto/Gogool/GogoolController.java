package Meta2Projeto.Gogool;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.apache.commons.validator.routines.UrlValidator;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

import java.rmi.RemoteException;

import java.util.stream.Collectors;

/**
 * Classe controladora responsavel por lidar com as requisicoes relacionadas ao Gogool.
 * Esta classe e responsavel por lidar com as requisicoes HTTP e fornecer respostas apropriadas.
 * 
 * @author Ana Carolina Morais e Fernanda Fernandes
 * @version 1.0
 */
@Controller
public class GogoolController {

    /**
     * Representa a conexao com o servico de login.
    */
    @Autowired
    private Connection loginService;


    /**
        * Retorna a pagina de pesquisa.
        *
        * @param model o modelo utilizado para adicionar atributos a pagina
        * @return o nome da pagina de pesquisa
    */
    @GetMapping("/search")
    public String search(Model model) {
        model.addAttribute("search", new Search());
        return "search";
    }

    /**
        * Metodo que recebe uma instância da classe Search e um objeto Model, realiza uma busca e retorna uma String com os resultados da busca.
        *
        * @param search instância da classe Search contendo o termo de busca
        * @param model objeto Model para adicionar os resultados da busca
        * @return uma String contendo os resultados da busca
        * @throws RemoteException se ocorrer um erro na conexao com o servico de login
    */
    @PostMapping("/search-result")
    public String searchResult(@ModelAttribute Search search, Model model) throws RemoteException {
        String message = loginService.getConnection().saySearch(search.getSearch());
        System.out.println("Search query: " + search.getSearch());
        System.out.println("Search results: " + message);

        String[] rawResults = message.split("\n\n");
        System.out.println("Number of results: " + rawResults.length);

        List<UrlModel> resultados = Arrays.stream(rawResults)
                .map(rawResult -> {
                    int urlStartIndex = rawResult.indexOf("http");
                    if (urlStartIndex != -1) {
                        String title = rawResult.substring(0, urlStartIndex).trim();
                        String urlAndParagraph = rawResult.substring(urlStartIndex).trim();

                        int urlEndIndex = urlAndParagraph.indexOf(" ");
                        String url = urlEndIndex != -1 ? urlAndParagraph.substring(0, urlEndIndex).trim() : urlAndParagraph;
                        String paragraph = urlEndIndex != -1 ? urlAndParagraph.substring(urlEndIndex).trim() : "No paragraph";

                        String newUrl = shortenUrl(url);

                        return new UrlModel(newUrl, title, paragraph);
                    } else {
                        return new UrlModel("N/A", "N/A", "N/A");
                    }
                })
                .collect(Collectors.toList());

        model.addAttribute("resultados", resultados);

        return "search-result";
    }

    /**
     * Retorna a versao encurtada de uma URL longa usando o servico TinyURL.
     *
     * @param longUrl a URL longa a ser encurtada
     * @return a versao encurtada da URL
     * @throws RuntimeException se ocorrer um erro ao encurtar a URL
    */
    private String shortenUrl(String longUrl) {
        try {
            // Prepare the request URL
            String apiUrl = "http://tinyurl.com/api-create.php?url=" + longUrl;

            // Create RestTemplate
            RestTemplate restTemplate = new RestTemplate();

            // Send GET request to TinyURL API
            ResponseEntity<String> response = restTemplate.exchange(
                    apiUrl, HttpMethod.GET, null, String.class);

            // Check response status
            if (response.getStatusCode() == HttpStatus.OK) {
                // Return the shortened URL
                return response.getBody();
            } else {
                throw new RuntimeException("Failed to shorten URL: " + response.getStatusCode());
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error while shortening URL", e);
        }
    }

    /**
        * Retorna o formulario de login.
        * 
        * @param error   o parâmetro de erro (opcional) que indica se ocorreu um erro no login
        * @param model   o modelo usado para adicionar atributos ao modelo de visualizacao
        * @return        o nome da pagina de login
    */
    @GetMapping("/login")
    public String loginForm(@RequestParam(value = "error", required = false) String error, Model model) {
        if (error != null && error.equals("true")) {
            // Se o parâmetro de erro estiver presente e for "true", adicione uma mensagem de erro ao modelo
            model.addAttribute("errorMessage", "Invalid username or password.");
        }
        return "login";
    }

    /**
        * Metodo que processa o resultado do login.
        * 
        * @param login o objeto contendo as informacoes de login
        * @param model o objeto Model usado para adicionar atributos a view
        * @return o nome da view "login-result"
        * @throws RemoteException se ocorrer um erro de comunicacao remota
    */
    @PostMapping("/login-result")
    public String LoginResult(@ModelAttribute Login login, Model model) throws RemoteException {
        String s = loginService.getConnection().sayLogin(login.getUsername(), login.getPassword());
        model.addAttribute("message", s);
        return "login-result";
    }

    /**
        * Retorna a pagina de registo.
        *
        * @param model o objeto Model usado para adicionar atributos a pagina
        * @return o nome da pagina de registo
    */
    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("regist", new Login());
        return "register";
    }

    /**
        * Regista o resultado do login.
        * 
        * @param login o objeto Login contendo as informacoes de login
        * @param model o objeto Model para adicionar atributos
        * @return a pagina "register-result" com a mensagem de resultado do registo
        * @throws RemoteException se ocorrer um erro de comunicacao remota
    */
    @PostMapping("/register-result")
    public String registerResult(@ModelAttribute Login login, Model model) throws RemoteException {
        String s = loginService.getConnection().sayRegister(login.getUsername(), login.getPassword());
        model.addAttribute("message", s);
        return "register-result";
    }

    /**
        * Retorna a pagina "pointed-links" e adiciona um objeto UrlModel ao modelo.
        * 
        * @param model o modelo a ser preenchido com os atributos
        * @return o nome da pagina "pointed-links"
    */
    @GetMapping("/pointed-links")
    public String pointedToLink(Model model) {
        model.addAttribute("url", new UrlModel());
        return "pointed-links";
    }

    /**
        * Metodo que recebe uma URL e um Model e retorna uma String contendo os links apontados pela URL.
        * 
        * @param url   o objeto UrlModel contendo a URL a ser processada
        * @param model o objeto Model utilizado para adicionar os links apontados
        * @return uma String contendo os links apontados pela URL
        * @throws RemoteException se ocorrer um erro na conexao com o servico de login
    */
    @PostMapping("/pointed-links-result")
    public String pointedToLinkResult(UrlModel url, Model model) throws RemoteException {
        String pointedLinksResult = loginService.getConnection().sayPointToLink(url.getUrl());
        String [] urlList = pointedLinksResult.split("\n");
        model.addAttribute("pointedLinks", urlList);
        return "pointed-links-result";
    }

    /**
        * Retorna a pagina de indice.
        *
        * @param model o objeto Model usado para adicionar atributos a pagina
        * @return o nome da pagina de indice
    */
    @GetMapping("/index")
    public String index(Model model) {
        model.addAttribute("url", new UrlModel());
        return "index_url";
    }

    /**
        * Metodo responsavel por receber uma URL e enviar para o servico de login remoto.
        * 
        * @param urlModel o objeto contendo a URL a ser enviada
        * @param model o objeto Model para adicionar o resultado da operacao
        * @return a pagina "result" para exibir o resultado da operacao
        * @throws RemoteException se ocorrer um erro na comunicacao com o servico remoto
    */
    @PostMapping("/submit-url")
    public String submitUrl(@ModelAttribute UrlModel urlModel, Model model) throws RemoteException {
        String url = urlModel.getUrl();
        String message = loginService.getConnection().sayURL(url);
        model.addAttribute("message", message);
        return "result";
    }

    /**
        * Template para o envio de mensagens simples.
    */
    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    /**
        * Envia uma mensagem periodica para o destino "/topic/messages".
        * A mensagem contem as estatisticas retornadas pelo metodo sayStats() da classe Connection.
        * @throws RemoteException se ocorrer um erro de comunicacao remota
    */
    @Scheduled(fixedRate=5000)
    public void sendPeriodicMessage() throws RemoteException {
        String destination = "/topic/messages";
        messagingTemplate.convertAndSend(destination, new Message(loginService.getConnection().sayStats()));
    }

    /**
        * Retorna o nome do arquivo de formulario de historias do usuario.
        *
        * @return o nome do arquivo de formulario de historias do usuario
    */
    @GetMapping("/user")
    public String getUserStoriesForm() {
        return "user_stories_form";
    }

    /**
        * Metodo que recebe o nome de usuario e um objeto Model como parâmetros e retorna uma String.
        * 
        * @param username O nome de usuario.
        * @param model O objeto Model usado para adicionar atributos.
        * @return A pagina "user_stories" ou a pagina de erro.
    */
    @PostMapping("/user-urls")
    public String getUserStories(@RequestParam("username") String username, Model model) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            String url = "https://hacker-news.firebaseio.com/v0/user/" + username + ".json?auth=pretty";
            HackerNewsUserRecord userRecord = restTemplate.getForObject(url, HackerNewsUserRecord.class);
            assert userRecord != null;
            List submittedStoryIds = userRecord.submitted();
            List<String> submittedStoriesURLS = new ArrayList<>();
            for (Object submittedStoryId : submittedStoryIds) {
                String urlStory = "https://hacker-news.firebaseio.com/v0/item/" + submittedStoryId + ".json?auth=pretty";
                HackerNewsItemRecord story = restTemplate.getForObject(urlStory, HackerNewsItemRecord.class);
                if (story != null) {
                    submittedStoriesURLS.add(story.url());
                    loginService.getConnection().sayURL(story.url());
                }
            }
            model.addAttribute("stories", submittedStoriesURLS);
            return "user_stories";
        } catch (Exception e) {
            // Handle the exception and return an appropriate error view
            return "error";
        }
    }

        /**
         * Obtem as principais historias do Hacker News e adiciona as URLs das historias ao modelo.
         * 
         * @param model O modelo usado para adicionar as URLs das historias.
         * @return A pagina "top10stories" que exibe as URLs das principais historias.
         * @throws RemoteException Se ocorrer um erro ao obter as historias do Hacker News.
         */
        @GetMapping("/list")
        public String hackerNewsTopStories(Model model) throws RemoteException {

            RestTemplate restTemplate = new RestTemplate();

            String url = "https://hacker-news.firebaseio.com/v0/topstories.json?auth=pretty";
            int[] storyIds = restTemplate.getForObject(url, int[].class);
            List<HackerNewsItemRecord> topStories = new ArrayList<>();
            List<String> urls = new ArrayList<>();
            for (int i = 0; i < 10 && i < storyIds.length; i++) {
                String urlstory = "https://hacker-news.firebaseio.com/v0/item/" + storyIds[i] + ".json?auth=pretty";
                HackerNewsItemRecord story = restTemplate.getForObject(urlstory, HackerNewsItemRecord.class);
                topStories.add(story);
                if (story != null) {
                    loginService.getConnection().sayURL(story.url());
                    urls.add(story.url());
                }
            }
            model.addAttribute("stories", urls);
            return "top10stories";

        }

}




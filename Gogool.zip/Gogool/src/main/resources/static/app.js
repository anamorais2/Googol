var stompClient = null;

function setConnected(connected) {
    $("#connect").prop("disabled", connected);
    $("#disconnect").prop("disabled", !connected);
    if (connected) {
        $("#conversation").show();
    } else {
        $("#conversation").hide();
    }
    $("#messages").html("");
}

function connect() {
    var socket = new SockJS('/my-websocket');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        setConnected(true);
        console.log('Connected: ' + frame);
        stompClient.subscribe('/topic/messages', function (message) {
            showMessage(JSON.parse(message.body));
        });
        stompClient.send("/app/message", {});
    });
}

function disconnect() {
    if (stompClient !== null) {
        stompClient.disconnect();
    }
    setConnected(false);
    console.log("Disconnected");
}

function sendMessage() {
    stompClient.send("/topic/messages", {});
}

function showMessage(message) {
    $("#messages").append("<tr><td>" + message.content + "</td></tr>");
}

$(function () {
    $("#connect").click(function () { connect(); });
    $("#disconnect").click(function () { disconnect(); });
    $("#send").click(function () { sendMessage(); });
    $("form").on('submit', function (e) {
        e.preventDefault();
    });
});

function checkCredentials() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === 'validUsername' && password === 'validPassword') {
        // Credentials are valid, proceed with login
        alert('Login successful!');
    } else {
        // Credentials are invalid, display error message
        document.getElementById('error-message').style.display = 'block';
    }
}

function submitLoginForm() {
    var form = document.getElementById("login-form");
    var formData = new FormData(form);

    fetch(form.action, {
        method: form.method,
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(error => {
                var errorMessage = document.querySelector('.error-message');
                errorMessage.textContent = error; // Exibe a mensagem de erro na página
                errorMessage.style.display = 'block'; // Mostra o elemento
            });
        }
        window.location.href = '/search'; // Redireciona para a página de home se o login for bem-sucedido
    })
    .catch(error => console.error('Error:', error));
}

document.addEventListener("DOMContentLoaded", function() {
    // This function will be called when the HTML document is loaded
    connect(); // Call the connect function
});

package Meta2Projeto.Gogool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GogoolApplicationTests {

	@Test
	void contextLoads() {
	}

}

# Googol: Motor de pesquisa de páginas Web

Nesta etapa do projeto, o nosso foco está na criação de um frontend web para a nossa aplicação Googol. O principal objetivo é tornarmos o serviço acessível a partir de uma ampla variedade de dispositivos conectados à internet, eliminando a necessidade de instalar software cliente. Para garantir a consistência de funcionalidades com a aplicação desktop desenvolvida anteriormente, vamos utilizar o servidor RMI que construímos na fase anterior. Priorizaremos abordagens modernas para proporcionar uma experiência interativa e em tempo real aos usuários. 
Além disso, integraremos as APIs do Hacker News e do “TinyURL” para agregar valor à nossa aplicação.

## Arquitetura do Sistema

![ ](Arquitetura.png)

## Manual de Instalação

1. O nosso projeto foi desenvolvido no ambiente proporcionado pelo IntelliJ IDEA. Portanto, para garantir a melhor compatibilidade, recomendamos a instalação deste software.

    - o website onde é possível proceder ao download e à sua instalação [IntelliJ](https://www.jetbrains.com/idea/?var=1).

2. Além disso, utilizamos a biblioteca [Jsoup](https://jsoup.org/) em nosso projeto, o que implica na necessidade de adicionar essa dependência.

3. Para esta etapa, é necessário proceder ao download do Maven, uma vez que esta parte do projeto contém várias depêndencias que se torna mais fáceis de resolver através do mmesmo. Após o download é necessário adicionar ás variáveis ambiente. 

    - o website onde é possível proceder ao download e à sua instalação [Maven](https://maven.apache.org/download.cgi).

4. Caso seja necessário, devido ás versões, realize o download de um novo projeto [Spring Boot](https://start.spring.io/) e escolha todas as dependências necessárias. 

    - Spring Web.
    - Thymeleaf.
    - Spring Boot DevTools
    - WebSocket


## Como executar o projeto 

1.  Abra o documento "config.properties";

2.  Nesse documento irá alterar o valor referente à variável barrelIP, parte do IP, isto é introduzir o IP do computador do Barrel.

    Para saber o IP do computador, este procedimento depende do sistema operativo do seu dispositivo. Desta forma, terá de fazer uma das seguintes operações na sua Linha de Comandos:

    Windows:
    ```bash
    ipconfig 
    ```
    Unix based systems
    ```bash
    ifconfig 
    ```

    De seguida, nas variáveis GatewayIP, GatewayPort, BarrelPort, MULTICAST_ADDRESS, MULTICAST_PORT, DownloadServerPort terá de introduzir um porto ou ip (address), consoante a terminação, disponível para cada uma delas. 

3. Nosso programa `Storage Barrel` (StorageBarrel.java) recebe como parâmetro o nome de um ficheiro-txt. Para configurar isso, clique com o botão direito na classe, selecione Modify Run Configuration: depois, insira o nome do arquivo em Program Arguments, no nosso caso colocámos `StorageBarrel1.txt`. 

4. Para permitir a execução múltipla deste programa, na mesma aba, vá para Modify Options e ative Allow Multiple Instances.


- Para uma melhor compreensão dos 2 passos anteriores, anexámos duas imagens que mostra os mesmos.

    1.![ ](StorageBarrelConfig.png) 2.![ ](StorageBarrrelConfig2.png)


5. Agora estamos prontos para executar o projeto. 
Para isso, siga a sequência: execute DownloadServer, em seguida Gateway, depois StorageBarrel e finalmente GoogolAplication.

6.  Aceda ao web server usando o endereço ```localhost:8080``` ou com o ip do computador onde o servidor se encontra.

## Autores 

- Ana Carolina Morais
- Fernanda Fernandes